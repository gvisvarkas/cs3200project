package com.example.springtemplate.repositories.newRepositories;

import com.example.springtemplate.models.newModels.Rating;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

public interface RatingRepository
    extends CrudRepository<Rating, Integer> {

  @Query(value = "INSERT INTO ratings(user_id, product_id, score, comment, created, updated, id) VALUES(1, 1, :score, :comment, '2020-01-01 00:00:00', '2019-01-01 00:00:00', :id)", nativeQuery = true)
  public Rating createRating(@Param("id") Integer id,
      @Param("score") Integer score, @Param("comment") String comment);
}

package com.example.springtemplate.repositories.newRepositories;

import com.example.springtemplate.models.newModels.Product;
import org.springframework.data.repository.CrudRepository;

public interface ProductRepository
        extends CrudRepository<Product, Integer> {
}

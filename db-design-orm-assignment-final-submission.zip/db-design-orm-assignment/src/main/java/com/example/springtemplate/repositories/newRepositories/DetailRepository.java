package com.example.springtemplate.repositories.newRepositories;

import com.example.springtemplate.models.newModels.Detail;
import org.springframework.data.repository.CrudRepository;

public interface DetailRepository
        extends CrudRepository<Detail, Integer> {
}

package com.example.springtemplate.daos.newDaos;

import com.example.springtemplate.models.newModels.Rating;
import com.example.springtemplate.repositories.newRepositories.ProductRepository;
import com.example.springtemplate.repositories.newRepositories.RatingRepository;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin(origins = "*")
public class RatingOrmDao {

  @Autowired
  RatingRepository ratingRepository;

  @Autowired
  ProductRepository productRepository;

  @PostMapping("/orm/ratings")
  public Rating createRating(@RequestBody Rating rating) {
    return ratingRepository.save(rating);
  }

  @GetMapping("/orm/products/{productId}/ratings")
  public List<Rating> findRatingsByProduct(@PathVariable("productId") Integer productId) {
    return productRepository.findById(productId).get().getRatings();
  }

  /*@GetMapping("/orm/ratings/{ratingId}/orders/create/{price}/{status}/{numItems}/{paid}/{gift}")
  public Rating createOrderForRating(
      @PathVariable("ratingId") Integer ratingId,
      @PathVariable("price") Float price,
      @PathVariable("status") String status,
      @PathVariable("numItems") Integer numItems,
      @PathVariable("gift") Boolean gift
  ) {
    Rating rating = ratingRepository.findRatingById(ratingId);
    List<Order> ratingOrders = rating.getOrders();
    Order newOrder = new Order(price, status, numItems, gift);
    ratingOrders.add(newOrder);
    return ratingRepository.save(rating);
  }*/

  @GetMapping("/orm/ratings")
  public List<Rating> findAllRating() {
    return (List<Rating>) ratingRepository.findAll();
  }

  @GetMapping("/orm/ratings/{ratingId}")
  public Rating findRatingById(
      @PathVariable("ratingId") Integer id) {
    return ratingRepository.findById(id).get();
  }

  @DeleteMapping("orm/ratings/{ratingId}")
  public void deleteRating(
      @PathVariable("ratingId") Integer id) {
    ratingRepository.deleteById(id);
  }

  @PutMapping("/orm/ratings/{ratingId}")
  public Rating updateRating(
      @PathVariable("ratingId") Integer id,
      @RequestBody Rating ratingUpdates) {
    Rating rating = ratingRepository.findById(id).get();
    rating.setComment(ratingUpdates.getComment());
    rating.setScore(ratingUpdates.getScore());
    return ratingRepository.save(rating);
  }

  @GetMapping("/orm/ratings/create/{id}/{score}/{comment}")
  public Rating createRating(
      @PathVariable("score") Integer score,
      @PathVariable("comment") String comment,
      @PathVariable("id") Integer id) {
    return ratingRepository.createRating(id, score, comment);
  }




  /*@GetMapping("/orm/ratings/update/password/{ratingId}/{pw}")
  public Rating updateRatingPassword(
      @PathVariable("ratingId") Integer id,
      @PathVariable("pw") String password
  ) {
    Rating rating = ratingRepository.findRatingById(id);
    rating.setPassword(password);
    return ratingRepository.save(rating);
  }*/
}

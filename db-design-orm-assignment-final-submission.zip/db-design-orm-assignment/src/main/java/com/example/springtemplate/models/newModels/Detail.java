package com.example.springtemplate.models.newModels;

import com.fasterxml.jackson.annotation.JsonIgnore;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name = "details")
public class Detail {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Integer id;
  private int quantity;
  private float discount;
  private float price;
  //ProductName?

  @ManyToOne
  private Product product;

  @ManyToOne
  @JsonIgnore
  private Order order;

  @Transient
  public String getProductName() {
    return product.getName();
  }

  @Transient
  public Integer getOrderId() {
    return order.getId();
  }

  public Detail() {
  }

  public Detail(int quantity, float discount, float price, Product product) {
    this.quantity = quantity;
    this.discount = discount;
    this.price = price;
    this.product = product;
  }

  public Detail(int quantity, float price) {
    this.quantity = quantity;
    this.discount = 0;
    this.price = price;
  }

  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public int getQuantity() {
    return quantity;
  }

  public void setQuantity(int quantity) {
    this.quantity = quantity;
  }

  public float getDiscount() {
    return discount;
  }

  public void setDiscount(float discount) {
    this.discount = discount;
  }

  public float getPrice() {
    return price;
  }

  public void setPrice(float price) {
    this.price = price;
  }

  public Product getProduct() {
    return product;
  }

  public void setProduct(Product product) {
    this.product = product;
  }

  public Order getOrder() {
    return order;
  }

  public void setOrder(Order order) {
    this.order = order;
  }
}

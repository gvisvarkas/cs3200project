package com.example.springtemplate.models.newModels;

import com.fasterxml.jackson.annotation.JsonIgnore;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "products")
public class Product {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Integer id;
  private String name;
  private String category;
  private String sellerName;
  private Date posted;
  private Integer stock;

  @OneToMany(mappedBy = "product")
  private List<Rating> ratings;

  @OneToMany(mappedBy = "product")
  @JsonIgnore
  private List<Detail> details;

  public Product(String name, String category) {
    this.name = name;
    this.category = category;
    this.stock = 100;
    this.details = new ArrayList<Detail>();
    this.ratings = new ArrayList<Rating>();
  }

  public Product(String name, String category, String sellerName, Date posted,
      Integer stock, List<Rating> ratings,
      List<Detail> details) {
    this.name = name;
    this.category = category;
    this.sellerName = sellerName;
    this.posted = posted;
    this.stock = stock;
    this.ratings = ratings;
    this.details = details;
  }

  public Product() {
  }

  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getCategory() {
    return category;
  }

  public void setCategory(String category) {
    this.category = category;
  }

  public String getSellerName() {
    return sellerName;
  }

  public void setSellerName(String sellerName) {
    this.sellerName = sellerName;
  }

  public Date getPosted() {
    return posted;
  }

  public void setPosted(Date posted) {
    this.posted = posted;
  }

  public Integer getStock() {
    return stock;
  }

  public void setStock(Integer stock) {
    this.stock = stock;
  }

  public List<Rating> getRatings() {
    return ratings;
  }

  public void setRatings(List<Rating> ratings) {
    this.ratings = ratings;
  }

  public List<Detail> getDetails() {
    return details;
  }

  public void setDetails(List<Detail> details) {
    this.details = details;
  }
}

package com.example.springtemplate.daos.newDaos;

import com.example.springtemplate.models.newModels.Detail;
import com.example.springtemplate.models.newModels.Order;
import com.example.springtemplate.models.newModels.Detail;
import com.example.springtemplate.repositories.newRepositories.OrderRepository;
import com.example.springtemplate.repositories.newRepositories.DetailRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin(origins = "*")
public class DetailOrmDao {

  @Autowired
  DetailRepository detailRepository;

  @Autowired
  OrderRepository orderRepository;


  @GetMapping("/orm/orders/{id}/details")
  public List<Detail> findDetailsForOrders(
      @PathVariable("id") Integer orderId) {
    Order order = orderRepository.findById(orderId).get();
    return order.getDetails();
  }


  @GetMapping("/orm/details/{detailId}")
  public Detail findDetailById(
      @PathVariable("detailId") Integer id) {
    return detailRepository.findById(id).get();
  }

  @DeleteMapping("/orm/details/{detailId}")
  public void deleteDetail(
      @PathVariable("detailId") Integer id) {
    detailRepository.deleteById(id);
  }

  @PostMapping("/orm/details")
  public Detail createDetail(@RequestBody Detail detail) {
    return detailRepository.save(detail);
  }

  @PutMapping("/orm/details/{detailId}")
  public Detail updateDetail(
      @PathVariable("detailId") Integer id,
      @RequestBody Detail detailUpdate) {
    Detail detail = detailRepository.findById(id).get();
    detail.setDiscount(detailUpdate.getDiscount());
    detail.setPrice(detailUpdate.getPrice());
    detail.setQuantity(detailUpdate.getQuantity());
    return detailRepository.save(detail);
  }


  //**********************************************************************************************
  //**********************************************************************************************


  @GetMapping("/orm/details")
  public List<Detail> findAllDetails() {
    return (List<Detail>) detailRepository.findAll();
  }

}
package com.example.springtemplate.daos.newDaos;

import com.example.springtemplate.models.newModels.Customer;
import com.example.springtemplate.models.newModels.Order;
import com.example.springtemplate.repositories.newRepositories.CustomerRepository;
import com.example.springtemplate.repositories.newRepositories.OrderRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin(origins = "*")
public class OrderOrmDao {

  @Autowired
  CustomerRepository customerRepository;

  @Autowired
  OrderRepository orderRepository;

  @GetMapping("/orm/customers/{customerId}/orders")
  public List<Order> findOrdersByCustomer(
      @PathVariable("customerId") Integer id) {
    return customerRepository.findCustomerById(id).getOrders();
  }


  @GetMapping("/orm/orders")
  public List<Order> findAllOrders() {
    return (List<Order>) orderRepository.findAll();
  }

  @GetMapping("/orm/orders/{orderId}")
  public Order findOrderById(
      @PathVariable("orderId") Integer id) {
    return orderRepository.findById(id).get();
  }

  @PostMapping("/orm/orders")
  public Order createOrder(@RequestBody Order order) {
    return orderRepository.save(order);
  }


  @DeleteMapping("/orm/orders/{orderId}")
  public void deleteOrder(
      @PathVariable("orderId") Integer id) {
    orderRepository.deleteById(id);
  }

  @PutMapping("/orm/orders/{orderId}")
  public Order updateOrder(@PathVariable("orderId") Integer id,
      @RequestBody Order order) {
    Order oldOrder = orderRepository.findById(id).get();
    oldOrder.setGift(order.isGift());
    oldOrder.setAddress(order.getAddress());
    oldOrder.setUser(order.getUser());
    oldOrder.setDeliveryDate(order.getDeliveryDate());
    oldOrder.setNumItems(order.getNumItems());
    oldOrder.setStatus(order.getStatus());
    oldOrder.setPrice(order.getPrice());
    return orderRepository.save(oldOrder);
  }
  //**********************************************************************************************
  //**********************************************************************************************
  /*
  @GetMapping("/orm/customers/create/{fname}/{lname}/{uname}/{pw}/{email}")
  public Customer createCustomer(
      @PathVariable("fname") String firstName,
      @PathVariable("lname") String lastName,
      @PathVariable("uname") String username,
      @PathVariable("pw") String password,
      @PathVariable("email") String email
  ) {
    Customer newCustomer = new Customer(firstName, lastName, username, password, email, null, null,
        null);
    return customerRepository.save(newCustomer);
  }

  @GetMapping("/orm/customers/find")
  public List<Customer> findAllCustomer() {
    return customerRepository.findAllCustomers();
  }

  @GetMapping("/orm/customers/find/id/{customerId}")
  public Customer findCustomerById(
      @PathVariable("customerId") Integer id) {
    return customerRepository.findCustomerById(id);
  }

  @GetMapping("orm/customers/delete/{customerId}")
  public void deleteCustomer(
      @PathVariable("customerId") Integer id) {
    customerRepository.deleteById(id);
  }

  @GetMapping("/orm/customers/update/password/{customerId}/{pw}")
  public Customer updateCustomerPassword(
      @PathVariable("customerId") Integer id,
      @PathVariable("pw") String password
  ) {
    Customer customer = customerRepository.findCustomerById(id);
    customer.setPassword(password);
    return customerRepository.save(customer);
  }

   */
}

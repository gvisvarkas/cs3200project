package com.example.springtemplate.models.newModels;

import com.fasterxml.jackson.annotation.JsonIgnore;
import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "ratings")
public class Rating {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Integer id;
  private Integer score;
  private String comment;
  private Date created;
  private Date updated;


  @ManyToOne
  @JsonIgnore
  private Customer customer;

  @ManyToOne
  @JsonIgnore
  private Product product;

  public Rating(Integer id, Integer score, String comment, Date created, Date updated,
      Customer customer, Product product) {
    this.id = id;
    this.score = score;
    this.comment = comment;
    this.created = created;
    this.updated = updated;
    this.customer = customer;
    this.product = product;
  }

  public Rating(Integer id, Integer score, String comment) {
    this.id = id;
    this.score = score;
    this.comment = comment;
    this.created = new Date();
    this.updated = new Date();
    this.customer = new Customer();
    this.product = new Product();
  }

  public Rating() {
  }

  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public Integer getScore() {
    return score;
  }

  public void setScore(int score) {
    this.score = score;
  }

  public String getComment() {
    return comment;
  }

  public void setComment(String comment) {
    this.comment = comment;
  }

  public Date getCreated() {
    return created;
  }

  public void setCreated(Date created) {
    this.created = created;
  }

  public Date getUpdated() {
    return updated;
  }

  public void setUpdated(Date updated) {
    this.updated = updated;
  }

  public Customer getUser() {
    return customer;
  }

  public void setUser(Customer customer) {
    this.customer = customer;
  }

  public Product getProduct() {
    return product;
  }

  public void setProduct(Product product) {
    this.product = product;
  }
}

package com.example.springtemplate.models.newModels;


public enum OrderStatus {
  PACKING, SHIPPED, DELIVERED
}

package com.example.springtemplate.repositories.newRepositories;

import com.example.springtemplate.models.newModels.Order;
import org.springframework.data.repository.CrudRepository;

public interface OrderRepository
        extends CrudRepository<Order, Integer> {
}

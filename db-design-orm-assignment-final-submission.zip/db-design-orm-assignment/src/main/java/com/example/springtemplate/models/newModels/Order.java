package com.example.springtemplate.models.newModels;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "orders")
public class Order {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Integer id;

  private float price;
  private String address;
  private String status;
  private int numItems;
  private boolean gift;
  private Date deliveryDate;


  @ManyToOne
  private Customer customer;

  @OneToMany(mappedBy = "order")
  private List<Detail> details;

  public Order() {
  }

  public Order(float price, String status, int numItems, boolean gift) {
    this.price = price;
    this.status = status;
    this.numItems = numItems;
    this.gift = gift;
    this.details = new ArrayList<Detail>();
  }

  public Order(float price, String address,
      String status, int numItems, boolean paid, boolean gift, Date deliveryDate,
      Customer customer, List<Detail> details) {
    this.price = price;
    this.address = address;
    this.status = status;
    this.numItems = numItems;
    this.gift = gift;
    this.deliveryDate = deliveryDate;
    this.customer = customer;
    this.details = details;
  }

  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public float getPrice() {
    return price;
  }

  public void setPrice(float price) {
    this.price = price;
  }

  public String getAddress() {
    return address;
  }

  public void setAddress(String address) {
    this.address = address;
  }

  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }

  public int getNumItems() {
    return numItems;
  }

  public void setNumItems(int numItems) {
    this.numItems = numItems;
  }

  public boolean isGift() {
    return gift;
  }

  public void setGift(boolean gift) {
    this.gift = gift;
  }

  public Date getDeliveryDate() {
    return deliveryDate;
  }

  public void setDeliveryDate(Date deliveryDate) {
    this.deliveryDate = deliveryDate;
  }

  public Customer getUser() {
    return customer;
  }

  public void setUser(Customer customer) {
    this.customer = customer;
  }

  public List<Detail> getDetails() {
    return details;
  }

  public void setDetails(List<Detail> details) {
    this.details = details;
  }
}

package com.example.springtemplate.daos.newDaos;

import com.example.springtemplate.models.newModels.Customer;
import com.example.springtemplate.models.newModels.Order;
import com.example.springtemplate.models.newModels.OrderStatus;
import com.example.springtemplate.repositories.newRepositories.CustomerRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin(origins = "*")
public class CustomerOrmDao {

  @Autowired
  CustomerRepository customerRepository;

  @PostMapping("/orm/customers")
  public Customer createCustomer(@RequestBody Customer customer) {
    return customerRepository.save(customer);
  }

  @GetMapping("/orm/customers/{customerId}/orders/create/{price}/{status}/{numItems}/{paid}/{gift}")
  public Customer createOrderForCustomer(
      @PathVariable("customerId") Integer customerId,
      @PathVariable("price") Float price,
      @PathVariable("status") String status,
      @PathVariable("numItems") Integer numItems,
      @PathVariable("gift") Boolean gift
  ) {
    Customer customer = customerRepository.findCustomerById(customerId);
    List<Order> customerOrders = customer.getOrders();
    Order newOrder = new Order(price, status, numItems, gift);
    customerOrders.add(newOrder);
    return customerRepository.save(customer);
  }

  @GetMapping("/orm/customers")
  public List<Customer> findAllCustomer() {
    return customerRepository.findAllCustomers();
  }

  @GetMapping("/orm/customers/{customerId}")
  public Customer findCustomerById(
      @PathVariable("customerId") Integer id) {
    return customerRepository.findCustomerById(id);
  }

  @DeleteMapping("orm/customers/delete/{customerId}")
  public void deleteCustomer(
      @PathVariable("customerId") Integer id) {
    customerRepository.deleteById(id);
  }

  @GetMapping("/orm/customers/update/password/{customerId}/{pw}")
  public Customer updateCustomerPassword(
      @PathVariable("customerId") Integer id,
      @PathVariable("pw") String password
  ) {
    Customer customer = customerRepository.findCustomerById(id);
    customer.setPassword(password);
    return customerRepository.save(customer);
  }

  @PutMapping("/orm/customers/{customerId}")
  public Customer updateCustomer(
      @PathVariable("customerId") Integer id,
      @RequestBody Customer customerUpdates) {
    Customer customer = customerRepository.findCustomerById(id);
    customer.setFirstName(customerUpdates.getFirstName());
    customer.setLastName(customerUpdates.getLastName());
    customer.setUsername(customerUpdates.getUsername());
    customer.setPassword(customerUpdates.getPassword());
    customer.setEmail(customerUpdates.getEmail());
    return customerRepository.save(customer);
  }

}

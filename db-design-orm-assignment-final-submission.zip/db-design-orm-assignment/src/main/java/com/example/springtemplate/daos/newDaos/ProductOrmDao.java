package com.example.springtemplate.daos.newDaos;

import com.example.springtemplate.models.newModels.Product;
import com.example.springtemplate.models.newModels.Detail;
import com.example.springtemplate.repositories.newRepositories.DetailRepository;
import com.example.springtemplate.repositories.newRepositories.ProductRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin(origins = "*")
public class ProductOrmDao {

  @Autowired
  ProductRepository productRepository;

  @Autowired
  DetailRepository detailRepository;

  @GetMapping("/orm/detail/{detailId}/product")
  public Product findProductByDetail(@PathVariable("detailId") Integer detailId) {
    return detailRepository.findById(detailId).get().getProduct();
  }

  @GetMapping("/orm/products/{productId}")
  public Product findProductById(
      @PathVariable("productId") Integer id) {
    return productRepository.findById(id).get();
  }

  @PostMapping("/orm/products")
  public Product createProduct(@RequestBody Product product) {
    return productRepository.save(product);
  }

  @PutMapping("/orm/products/{productId}")
  public Product updateProduct(
      @PathVariable("productId") Integer id,
      @RequestBody Product productUpdates) {
    Product product = productRepository.findById(id).get();
    product.setCategory(productUpdates.getCategory());
    product.setPosted(productUpdates.getPosted());
    product.setName(productUpdates.getName());
    product.setStock(productUpdates.getStock());
    product.setSellerName(productUpdates.getSellerName());
    return productRepository.save(product);
  }

  //********************************************************************************************
  //********************************************************************************************


  @GetMapping("/orm/products")
  public List<Product> findAllProducts() {
    return (List<Product>) productRepository.findAll();
  }


  @GetMapping("/orm/products/{productId}/details/{quantity}/{price}")
  public Product createDetailForProduct(
      @PathVariable("productId") Integer id,
      @PathVariable("quantity") Integer quantity,
      @PathVariable("price") Float price
  ) {
    Detail newDetail = new Detail(quantity, price);
    Product product = productRepository.findById(id).get();
    List<Detail> productDetails = product.getDetails();
    productDetails.add(newDetail);
    return productRepository.save(product);
  }


  @GetMapping("/orm/update/product/{productId}/{stock}")
  public Product updateProductStock(
      @PathVariable("productId") Integer id,
      @PathVariable("stock") Integer stock) {
    Product Product = this.findProductById(id);
    Product.setStock(stock);
    return productRepository.save(Product);
  }

  @GetMapping("/orm/products/delete/{productId}")
  public void deleteProduct(
      @PathVariable("productId") Integer id) {
    productRepository.deleteById(id);
  }
}
import customerService from "../customers/customer-service";

const {useParams, useHistory} = window.ReactRouterDOM;
const {useState, useEffect} = React;
import ratingService from './rating-service'

const RatingFormEditor = () => {
  const {id} = useParams();
  const [rating, setRating] = useState(
      {userId: 1, id: 1, score: 5, comment: 'lorem ipsum', created: "2021-01-01T00:00:00.000+00:00", updated: "2021-01-01T00:00:00.000+00:00", product: 2});

  useEffect(() => {
    if (id !== "new") {
      findRatingById(id)
    }
  }, []);
  const createRating = (rating) =>
      ratingService.createRating(rating)
      .then(() => history.back())

  const findRatingById = (id) =>
      ratingService.findRatingById(id)
      .then(rating => setRating(rating));

  const deleteRating = (id) =>
      ratingService.deleteRating(id)
      .then(() => history.back())

  const updateRating = (id, newRating) =>
      ratingService.updateRating(id, newRating)
      .then(() => alert('Data is updated!'))

  return (
      <div className="container">
        <h2 className="text-center fs-1 fw-bolder mb-4">Update Rating</h2>
        {/*{JSON.stringify(rating)}*/}
        <div className='row'>
          <div className='col-6'>
            <label className="fw-bold">Score</label>
            <input onChange={(e) =>
                setRating(rating =>
                    ({...rating, score: e.target.value}))}
                   value={rating.score} className="form-control"/><br/>
          </div>
          <div className='col-6'>
            <label className="fw-bold">Comment</label>
            <input onChange={(e) =>
                setRating(rating =>
                    ({...rating, comment: e.target.value}))}
                   value={rating.comment} className="form-control"/><br/>
          </div>
        </div>
        <button className="btn btn-warning" onClick={() => {
          history.back()
        }}>
          Cancel
        </button>
        <button className="btn btn-danger"
                onClick={() => deleteRating(rating.id)}>
          Delete
        </button>
        <button className="btn btn-primary"
                onClick={() => createRating(rating)}>
          Create
        </button>
        <button className="btn btn-dark"
                onClick={() => updateRating(rating.id, rating)}>
          Update
        </button>
      </div>
  )
}

export default RatingFormEditor
// TODO: declare URL where server listens for HTTP requests
const RATINGS_URL = "http://localhost:8080/orm/ratings"

// TODO: retrieve all Ratings from the server
export const findAllRatings = () =>
    fetch(RATINGS_URL).then(response => response.json())

// TODO: retrieve a single Rating by their ID
export const findRatingById = (id) =>
    fetch(`${RATINGS_URL}/${id}`).then(response => response.json())

export const findRatingsByRating = (id) =>
    fetch(`http://localhost:8080/orm/ratings/${id}/ratings`).then(response => response.json())

export const findRatingByProduct = (id) =>
    fetch(`http://localhost:8080/orm/products/${id}/ratings`).then(
        response => response.json())

// TODO: delete a Rating by their ID
export const deleteRating = (id) =>
    fetch(`${RATINGS_URL}/${id}`,
        {method: "DELETE"})

// TODO: create a new Rating
export const createRating = (rating) =>
    fetch(RATINGS_URL, {
      method: 'POST',
      body: JSON.stringify(rating),
      headers: {'content-type': 'application/json'}
    })
    .then(response => response.json())

// TODO: update a Rating by their ID
export const updateRating = (id, rating) =>
    fetch(`${RATINGS_URL}/${id}`, {
      method: 'PUT',
      body: JSON.stringify(rating),
      headers: {'content-type': 'application/json'}
    })
    .then(response => response.json())

// TODO: export all functions as the API to this service
export default {
  findAllRatings,
  findRatingById,
  deleteRating,
  createRating,
  findRatingByProduct,
  updateRating
}

//import React from "react"
import RatingList from "./rating-list";
import RatingFormEditor from "./rating-form-editor";
import OrderList from "../orders/order-list";
import OrderFormEditor from "../orders/order-form-editor";
const {HashRouter, Route} = window.ReactRouterDOM;
const App = () => {
    return (
        <div className="container-fluid">
            <HashRouter>
                <Route path={["/ratings", "/"]} exact={true}>
                    <RatingList/>
                </Route>
                <Route path="/ratings/:id" exact={true}>
                    <RatingFormEditor/>
                </Route>
            </HashRouter>
        </div>
    );
}

export default App;

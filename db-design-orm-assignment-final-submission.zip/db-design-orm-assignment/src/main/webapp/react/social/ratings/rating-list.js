import ratingService from './rating-service'

const {useState, useEffect} = React;

const {Link, useHistory, useParams} = window.ReactRouterDOM;

const RatingList = () => {
  const {id} = useParams();
  const history = useHistory();
  const [ratings, setRatings] = useState([]);
  const findRatingByProduct = (id) =>
      ratingService.findRatingByProduct(id)
      .then(users => setRatings(users))
  useEffect(() => {
    findRatingByProduct(id)
  }, [])

  return (
      <div className='container'>
        <div className='position-relative'>
          <div>
            <h3 className='text-center fs-1 fw-bolder'>Rating List</h3>
            {/*{JSON.stringify(ratings)}*/}
          </div>
          <div className='position-absolute top-50 end-0'>
            <button onClick={() => history.push("/ratings/new")}
                    className="btn btn-success">
              Add Rating
            </button>
          </div>
        </div>


        <ul className="list-group">
          {
            ratings.map(rating =>
                <li className="list-group-item" key={rating.id}>
                  <Link to={`/ratings/${rating.id}`}>
                    <p className="no-underline">
                      ID: {rating.id} </p>
                    <p className="no-underline">
                      Score: {rating.score} </p>
                  </Link>
                </li>
            )
          }
        </ul>
      </div>
  )
}

export default RatingList;
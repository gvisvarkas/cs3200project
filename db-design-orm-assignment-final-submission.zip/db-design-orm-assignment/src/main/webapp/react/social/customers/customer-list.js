import customerService from './customer-service'

const {useState, useEffect} = React;

const {Link, useHistory} = window.ReactRouterDOM;

const CustomerList = () => {
  const history = useHistory();
  const [customers, setCustomers] = useState([]);
  const findAllCustomers = () =>
      customerService.findAllCustomers()
      .then(users => setCustomers(users))
  useEffect(() => {
    findAllCustomers()
  }, [])

  return (
      <div className='container'>
        <div className='position-relative'>
          <div>
            <h3 className='text-center fs-1 fw-bolder'>Customer List</h3>
          </div>
          <div className='position-absolute top-50 end-0'>
            <button onClick={() => history.push("/customers/new")}
                    className="btn btn-success">
              <i className="fas fa-user-plus"></i>
            </button>
          </div>
        </div>


        <ul className="list-group">
          {
            customers.map(customer =>
                <li className="list-group-item" key={customer.id}>
                  <Link to={`/customers/${customer.id}`}>
                    <p className="no-underline">
                      Name: {customer.firstName} {customer.lastName} </p>
                    <p className="no-underline">
                      Username: {customer.username} </p>
                    <p className="no-underline">
                      Email: {customer.email}
                    </p>
                  </Link>
                </li>
            )
          }
        </ul>
      </div>
  )
}

export default CustomerList;
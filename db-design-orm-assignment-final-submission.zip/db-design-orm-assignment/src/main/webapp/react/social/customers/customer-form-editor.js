const {useParams, useHistory, Link} = window.ReactRouterDOM;
const {useState, useEffect} = React;
import customerService from './customer-service'

const CustomerFormEditor = () => {
  const {id} = useParams();
  const [customer, setCustomer] = useState({});

  useEffect(() => {
    if (id !== "new") {
      findCustomerById(id)
    }
  }, []);
  const createCustomer = (customer) =>
      customerService.createCustomer(customer)
      .then(() => history.back())

  const findCustomerById = (id) =>
      customerService.findCustomerById(id)
      .then(customer => setCustomer(customer));

  const deleteCustomer = (id) =>
      customerService.deleteCustomer(id)
      .then(() => history.back())

  const updateCustomer = (id, newCustomer) =>
      customerService.updateCustomer(id, newCustomer)
      .then(() => alert('Data is updated!'))

  return (
      <div className="container">
        <h2 className="text-center fs-1 fw-bolder mb-4">Update Profile</h2>
        <div className='row'>
          <div className='col-6'>
            <label className="fw-bold">First Name</label>
            <input onChange={(e) =>
                setCustomer(customer =>
                    ({...customer, firstName: e.target.value}))}
                   value={customer.firstName} className="form-control"/><br/>
          </div>
          <div className='col-6'>
            <label className="fw-bold">Last Name</label>
            <input onChange={(e) =>
                setCustomer(customer =>
                    ({...customer, lastName: e.target.value}))}
                   value={customer.lastName} className="form-control"/><br/>
          </div>
        </div>
        <div className='row'>
          <div className='col-6'>
            <label className="fw-bold">Username</label>
            <input onChange={(e) =>
                setCustomer(customer =>
                    ({...customer, username: e.target.value}))}
                   value={customer.username} className="form-control"/><br/>
          </div>
          <div className='col-6'>
            <label className="fw-bold">Email</label>
            <input onChange={(e) =>
                setCustomer(customer =>
                    ({...customer, email: e.target.value}))}
                   value={customer.email} className="form-control"/><br/>
          </div>
        </div>
        <div className='row'>
          <div className='col-6'>
            <label className="fw-bold">Password</label>
            <input onChange={(e) =>
                setCustomer(customer =>
                    ({...customer, password: e.target.value}))}
                   value={customer.password} className="form-control"/>
            <br/>
          </div>
        </div>

        <div className='mb-4 row'>
          <div className='col-10'>
            <button className="btn btn-warning" onClick={() => {
              history.back()
            }}>
              Cancel
            </button>
            <button className="btn btn-danger"
                    onClick={() => deleteCustomer(customer.id)}>
              Delete
            </button>
            <button className="btn btn-primary"
                    onClick={() => createCustomer(customer)}>
              Create
            </button>
            <button className="btn btn-dark"
                    onClick={() => updateCustomer(customer.id, customer)}>
              Update
            </button>
          </div>

          <div className='col-2'>
            <Link className='btn btn-info'
                  to={`/customers/${customer.id}/orders`}>
              All Orders for {customer.firstName}
            </Link>
          </div>
        </div>
      </div>
  )
}

export default CustomerFormEditor
//import React from "react"
import CustomerList from "./customer-list";
import CustomerFormEditor from "./customer-form-editor";
import OrderList from "../orders/order-list";
import OrderFormEditor from "../orders/order-form-editor";
import DetailList from "../details/detail-list";
import DetailFormEditor from "../details/detail-form-editor";
import ProductList from "../products/product-list";
import ProductFormEditor from "../products/product-form-editor";
import RatingFormEditor from "../ratings/rating-form-editor";
import RatingList from "../ratings/rating-list";

const {HashRouter, Route} = window.ReactRouterDOM;
const App = () => {
  return (
      <div className="container-fluid">
        <HashRouter>
          <Route path={["/customers", "/"]} exact={true}>
            <CustomerList/>
          </Route>
          <Route path="/customers/:id" exact={true}>
            <CustomerFormEditor/>
          </Route>
          <Route path={["/customers/:id/orders"]} exact={true}>
            <OrderList/>
          </Route>
          <Route path={["/orders/:id"]} exact={true}>
            <OrderFormEditor/>
          </Route>
          <Route path={["/orders/:id/details"]} exact={true}>
            <DetailList/>
          </Route>
          <Route path={["/details/:id"]} exact={true}>
            <DetailFormEditor/>
          </Route>
          <Route path={["/details/:id/product"]} exact={true}>
            <ProductList/>
          </Route>
          <Route path={["/products/:id"]} exact={true}>
            <ProductFormEditor/>
          </Route>
          <Route path={["/products/:id/ratings"]} exact={true}>
            <RatingList/>
          </Route>
          <Route path={["/ratings/:id"]} exact={true}>
            <RatingFormEditor/>
          </Route>
        </HashRouter>
      </div>
  );
}

// TODO: getOrdersByCustomer, getOrderById(id) || getDetailsByOrder(orderId), getDetailsById(detailId)
// TODO: getProductsByDetail(detailId), getProductsById(productId)
export default App;

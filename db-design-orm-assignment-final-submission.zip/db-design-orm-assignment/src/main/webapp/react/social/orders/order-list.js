import orderService from './order-service'

const {useState, useEffect} = React;

const {Link, useHistory, useParams} = window.ReactRouterDOM;

const OrderList = () => {
  const {id} = useParams();
  const history = useHistory();
  const [orders, setOrders] = useState([]);
  const findOrdersByCustomer = (id) =>
      orderService.findOrdersByCustomer(id)
      .then(orders => setOrders(orders))
  useEffect(() => {
    findOrdersByCustomer(id)
  }, [])

  return (
      <div className='container'>
        <div className='position-relative'>
          <div>
            <h3 className='text-center fs-1 fw-bolder'>Order List</h3>
          </div>
          <div className='position-absolute top-50 end-0'>
            <button onClick={() => history.push("/orders/new")}
                    className="btn btn-success">
              <i className="fas fa-user-plus"></i>
            </button>
          </div>
        </div>


        <ul className="list-group">
          {
            orders.map(order =>
                <li className="list-group-item" key={order.id}>
                  <Link to={`/orders/${order.id}`}>
                    <p className="no-underline">
                      Order #: {order.id} </p>
                    <p className="no-underline">
                      Price: {order.price} </p>
                    <p className="no-underline">
                      Shipping Status: {order.status} </p>
                  </Link>
                </li>
            )
          }
        </ul>

      </div>
  )
}

export default OrderList;
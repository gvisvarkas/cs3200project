const {useParams, useHistory, Link} = window.ReactRouterDOM;
const {useState, useEffect} = React;
import orderService from './order-service'

const OrderFormEditor = () => {
  const {id} = useParams();
  const [order, setOrder] = useState(
      {user: {id: -1, firstName: 'Quang', lastName: 'Ngo'}});

  useEffect(() => {
    if (id !== "new") {
      findOrderById(id)
    }
  }, []);
  const createOrder = (order) =>
      orderService.createOrder(order)
      .then(() => history.back())

  const findOrderById = (id) =>
      orderService.findOrderById(id)
      .then(order => setOrder(order));

  const deleteOrder = (id) =>
      orderService.deleteOrder(id)
      .then(() => history.back());

  const updateOrder = (id, order) =>
      orderService.updateOrder((id, order))
      .then(() => alert('Data is updated!'));

  return (
      <div className="container">
        <h2 className="text-center fs-1 fw-bolder mb-4">Update Order</h2>

        <div className='row'>
          <div className='col-6'>
            <label className="fw-bold">Price</label>
            <input onChange={(e) =>
                setOrder(order =>
                    ({...order, price: e.target.value}))}
                   value={order.price} className="form-control"/><br/>
          </div>
          <div className='col-6'>
            <label className="fw-bold">Address</label>
            <input onChange={(e) =>
                setOrder(order =>
                    ({...order, address: e.target.value}))}
                   value={order.address} className="form-control"/><br/>
          </div>
        </div>
        <div className='row'>
          <div className='col-6'>
            <label className="fw-bold">Status</label>
            <input onChange={(e) =>
                setOrder(order =>
                    ({...order, status: e.target.value}))}
                   value={order.status} className="form-control"/><br/>
          </div>
          <div className='col-6'>
            <label className="fw-bold">Number of Items</label>
            <input onChange={(e) =>
                setOrder(order =>
                    ({...order, numItems: e.target.value}))}
                   value={order.numItems} className="form-control"/><br/>
          </div>
        </div>

        <h4>
          Customer: <Link
            to={`/customers/${order.user['id']}`}>{order.user['firstName']}</Link>
        </h4>

        <div className='row'>
          <div className='col-9'>
            <button className="btn btn-warning" onClick={() => {
              history.back()
            }}>
              Cancel
            </button>
            <button className="btn btn-danger"
                    onClick={() => deleteOrder(order.id)}>
              Delete
            </button>
            <button className="btn btn-primary"
                    onClick={() => createOrder(order)}>
              Create
            </button>
            <button className="btn btn-dark"
                    onClick={() => updateOrder(order.id, order)}>
              Update
            </button>
          </div>

          <div className='col-3'>
            <Link className='btn btn-info' to={`/orders/${id}/details`}>
              Retrieve all the details of this order #{id}
            </Link>
          </div>
        </div>

      </div>
  )
}

export default OrderFormEditor
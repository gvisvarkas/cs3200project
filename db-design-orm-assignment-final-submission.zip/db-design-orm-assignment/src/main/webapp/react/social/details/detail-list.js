import detailService from './detail-service'

const {useState, useEffect} = React;

const {Link, useHistory, useParams} = window.ReactRouterDOM;

const DetailList = () => {
  const {id} = useParams();
  const history = useHistory();
  const [details, setDetails] = useState([]);
  const findDetailsByOrder = (id) =>
      detailService.findDetailsByOrder(id)
      .then(details => setDetails(details))
  useEffect(() => {
    findDetailsByOrder(id)
  }, [])

  return (
      <div className='container'>
        <div className='position-relative'>
          <div>
            <h3 className='text-center fs-1 fw-bolder'>Detail List</h3>
          </div>
          <div className='position-absolute top-50 end-0'>
            <button onClick={() => history.push("/details/new")}
                    className="btn btn-success">
              <i className="fas fa-user-plus"></i>
            </button>
          </div>
        </div>


        <ul className="list-group">
          {
            details.map(detail =>
                <li className="list-group-item" key={detail.id}>
                  <Link to={`/details/${detail.id}`}>
                    <p className="no-underline">
                      Detail ID: {detail.id} </p>
                    <p className="no-underline">
                      Product: {detail.product.name} </p>
                  </Link>
                </li>
            )
          }
        </ul>
      </div>
  )
}

export default DetailList;
// TODO: declare URL where server listens for HTTP requests
const DETAILS_URL = "http://localhost:8080/orm/details"

// TODO: retrieve all Details from the server
export const findAllDetails = () =>
    fetch(DETAILS_URL).then(response => response.json())

// TODO: retrieve a single Detail by their ID
export const findDetailById = (id) =>
    fetch(`${DETAILS_URL}/${id}`).then(response => response.json())

export const findDetailsByOrder = (id) =>
    fetch(`http://localhost:8080/orm/orders/${id}/details`).then(
        response => response.json())

// TODO: delete a Detail by their ID
export const deleteDetail = (id) =>
    fetch(`${DETAILS_URL}/${id}`,
        {method: "DELETE"})

// TODO: create a new Detail
export const createDetail = (detail) =>
    fetch(DETAILS_URL, {
      method: 'POST',
      body: JSON.stringify(detail),
      headers: {'content-type': 'application/json'}
    })
    .then(response => response.json())

// TODO: update a Detail by their ID
export const updateDetail = (id, detail) =>
    fetch(`${DETAILS_URL}/${id}`, {
      method: 'PUT',
      body: JSON.stringify(detail),
      headers: {'content-type': 'application/json'}
    })
    .then(response => response.json())

// TODO: export all functions as the API to this service
export default {
  findAllDetails,
  findDetailById,
  deleteDetail,
  createDetail,
  findDetailsByOrder,
  updateDetail
}

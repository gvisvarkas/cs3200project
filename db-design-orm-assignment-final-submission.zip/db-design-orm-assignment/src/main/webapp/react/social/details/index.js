//import React from "react"
import DetailList from "./detail-list";
import DetailFormEditor from "./detail-form-editor";
import OrderList from "../orders/order-list";
import OrderFormEditor from "../orders/order-form-editor";
const {HashRouter, Route} = window.ReactRouterDOM;
const App = () => {
    return (
        <div className="container-fluid">
            <HashRouter>
                <Route path={["/details", "/"]} exact={true}>
                    <DetailList/>
                </Route>
                <Route path="/details/:id" exact={true}>
                    <DetailFormEditor/>
                </Route>
            </HashRouter>
        </div>
    );
}

export default App;

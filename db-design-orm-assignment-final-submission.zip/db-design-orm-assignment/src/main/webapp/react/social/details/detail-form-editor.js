import ProductFormEditor from "../products/product-form-editor";

const {useParams, useHistory, Link} = window.ReactRouterDOM;
const {useState, useEffect} = React;
import detailService from './detail-service'
import customerService from "../customers/customer-service";

const DetailFormEditor = () => {
  const {id} = useParams();
  const [detail, setDetail] = useState(
      {id: -1, product: {id: -1, name: 'Shoes'}});

  useEffect(() => {
    if (id !== "new") {
      findDetailById(id)
    }
  }, []);
  const createDetail = (detail) =>
      detailService.createDetail(detail)
      .then(() => history.back())

  const findDetailById = (id) =>
      detailService.findDetailById(id)
      .then(detail => setDetail(detail));
  
  const deleteDetail = (id) =>
      detailService.deleteDetail(id)
      .then(() => history.back())

  const updateDetail = (id, newDetail) =>
      detailService.updateDetail(id, newDetail)
      .then(() => alert('Data is updated!'))


  return (
      <div className="container">
        <h2 className="text-center fs-1 fw-bolder mb-4">Update Detail</h2>
        {/*{JSON.stringify(detail)}*/}
        <div className='row'>
          <div className='col-6'>
            <label className="fw-bold">Quantity</label>
            <input onChange={(e) =>
                setDetail(detail =>
                    ({...detail, quantity: e.target.value}))}
                   value={detail.quantity} className="form-control"/><br/>
          </div>
          <div className='col-6'>
            <label className="fw-bold">Discount</label>
            <input onChange={(e) =>
                setDetail(detail =>
                    ({...detail, discount: e.target.value}))}
                   value={detail.discount} className="form-control"/><br/>
          </div>
        </div>
        <div className='row'>
          <div className='col-6'>
            <label className="fw-bold">Price</label>
            <input onChange={(e) =>
                setDetail(detail =>
                    ({...detail, price: e.target.value}))}
                   value={detail.price} className="form-control"/><br/>
          </div>
          <div className='col-6'>
            <label className="fw-bold">Product</label>
            <input onChange={(e) =>
                setDetail(detail =>
                    ({...detail, product: {... detail.product, name: e.target.value}}))}
                   value={detail.product.name} className="form-control"/><br/>
          </div>
        </div>

        <div>
          <h5>Oder #:</h5>
          <Link to={`/orders/1`}>

          </Link>
        </div>

        <div className='row'>
          <div className='col-9'>
            <button className="btn btn-warning" onClick={() => {
              history.back()
            }}>
              Cancel
            </button>
            <button className="btn btn-danger"
                    onClick={() => deleteDetail(detail.id)}>
              Delete
            </button>
            <button className="btn btn-primary"
                    onClick={() => createDetail(detail)}>
              Create
            </button>
            <button className="btn btn-dark"
                    onClick={() => updateDetail(detail.id, detail)}>
              Update
            </button>
          </div>

          <div className='col-3'>
            <Link className='btn btn-info' to={`/products/${detail.product.id}`}>
              Get the product of this detail #{detail.id}
            </Link>
          </div>
        </div>
      </div>
  )
}

export default DetailFormEditor
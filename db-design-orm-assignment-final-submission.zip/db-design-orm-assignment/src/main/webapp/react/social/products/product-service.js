// TODO: declare URL where server listens for HTTP requests
const PRODUCTS_URL = "http://localhost:8080/orm/products"

// TODO: retrieve all Products from the server
export const findAllProducts = () =>
    fetch(PRODUCTS_URL).then(response => response.json())

// TODO: retrieve a single Product by their ID
export const findProductById = (id) =>
    fetch(`${PRODUCTS_URL}/${id}`).then(response => response.json())

export const findRatingsByProduct = (id) =>
    fetch(`http://localhost:8080/orm/products/${id}/ratings`).then(response => response.json())

export const findProductByDetail = (id) =>
    fetch(`http://localhost:8080/orm/detail/${id}/product`).then(
        response => response.json())

// TODO: delete a Product by their ID
export const deleteProduct = (id) =>
    fetch(`${PRODUCTS_URL}/${id}`,
        {method: "DELETE"})

// TODO: create a new Product
export const createProduct = (product) =>
    fetch(PRODUCTS_URL, {
      method: 'POST',
      body: JSON.stringify(product),
      headers: {'content-type': 'application/json'}
    })
    .then(response => response.json())

// TODO: update a Product by their ID
export const updateProduct = (id, product) =>
    fetch(`${PRODUCTS_URL}/${id}`, {
      method: 'PUT',
      body: JSON.stringify(product),
      headers: {'content-type': 'application/json'}
    })
    .then(response => response.json())

// TODO: export all functions as the API to this service
export default {
  findAllProducts,
  findProductById,
  deleteProduct,
  createProduct,
  findProductByDetail,
  updateProduct
}

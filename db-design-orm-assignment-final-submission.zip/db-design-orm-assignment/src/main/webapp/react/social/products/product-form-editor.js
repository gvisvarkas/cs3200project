import customerService from "../customers/customer-service";

const {useParams, useHistory, Link} = window.ReactRouterDOM;
const {useState, useEffect} = React;
import productService from './product-service'

const ProductFormEditor = () => {
  const {id} = useParams();
  const [product, setProduct] = useState({});

  useEffect(() => {
    if (id !== "new") {
      findProductById(id)
    }
  }, []);
  const createProduct = (product) =>
      productService.createProduct(product)
      .then(() => history.back())

  const findProductById = (id) =>
      productService.findProductById(id)
      .then(product => setProduct(product));

  const deleteProduct = (id) =>
      productService.deleteProduct(id)
      .then(() => history.back())

  const updateProduct = (id, newProduct) =>
      productService.updateProduct(id, newProduct)
      .then(() => alert('Data is updated!'))

  return (
      <div className="container">
        <h2 className="text-center fs-1 fw-bolder mb-4">Update Product</h2>
        <div className='row'>
          <div className='col-6'>
            <label className="fw-bold">Name</label>
            <input onChange={(e) =>
                setProduct(product =>
                    ({...product, name: e.target.value}))}
                   value={product.name} className="form-control"/><br/>
          </div>
          <div className='col-6'>
            <label className="fw-bold">Category</label>
            <input onChange={(e) =>
                setProduct(product =>
                    ({...product, category: e.target.value}))}
                   value={product.category} className="form-control"/><br/>
          </div>
        </div>
        <div className='row'>
          <div className='col-6'>
            <label className="fw-bold">Seller</label>
            <input onChange={(e) =>
                setProduct(product =>
                    ({...product, sellerName: e.target.value}))}
                   value={product.sellerName} className="form-control"/><br/>
          </div>
        </div>

        <div className='row'>
          <div className='col-9'>
            <button className="btn btn-warning" onClick={() => {
              history.back()
            }}>
              Cancel
            </button>
            <button className="btn btn-danger"
                    onClick={() => deleteProduct(product.id)}>
              Delete
            </button>
            <button className="btn btn-primary"
                    onClick={() => createProduct(product)}>
              Create
            </button>
            <button className="btn btn-dark"
                    onClick={() => updateProduct(product.id, product)}>
              Update
            </button>
          </div>

          <div className='col-3'>
            <Link className='btn btn-info' to={`/products/${id}/ratings`}>
              Retrieve all the ratings of this product #{id}
            </Link>
          </div>
        </div>
      </div>
  )
}

export default ProductFormEditor
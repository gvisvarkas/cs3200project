import productService from './product-service'

const {useState, useEffect} = React;

const {Link, useHistory} = window.ReactRouterDOM;

const ProductList = () => {
  const history = useHistory();
  const [products, setProducts] = useState([]);
  const findAllProducts = () =>
      productService.findAllProducts()
      .then(users => setProducts(users))
  useEffect(() => {
    findAllProducts()
  }, [])

  return (
      <div className='container'>
        <div className='position-relative'>
          <div>
            <h3 className='text-center fs-1 fw-bolder'>Product List</h3>
          </div>
          <div className='position-absolute top-50 end-0'>
            <button onClick={() => history.push("/products/new")}
                    className="btn btn-success">
              <i className="fas fa-user-plus"></i>
            </button>
          </div>
        </div>


        <ul className="list-group">
          {
            products.map(product =>
                <li className="list-group-item" key={product.id}>
                  <Link to={`/products/${product.id}`}>
                    <p className="no-underline">
                      Name: {product.name} </p>
                    <p className="no-underline">
                      Category: {product.category} </p>
                  </Link>
                </li>
            )
          }
        </ul>
      </div>
  )
}

export default ProductList;